#-*-coding:utf-8-*-
from django.shortcuts import render,render_to_response
from django.template import RequestContext
from django.http import HttpResponse, HttpResponseRedirect
from django.http import JsonResponse
from tools.dbcon import *
from online.models import User
import json
import sys
import time
import  re
from django.views.decorators.cache import cache_page
reload(sys)
sys.setdefaultencoding('utf8')


#确定身份函数
def comfirm(req):
    if req.session['islogin'] == True:
        user_info = req.session['user_info']
        user_role = user_info['role']
        if user_role != '管理员':
            msg = '您不是管理员'
            return 0
        else:
            return 1

def index(req):
    if  comfirm(req):
        my_db = MynewcoderDB()
        sql = "select * from vip"
        infos = my_db.getInfo(sql)
        results = []
        for infos1_row in infos:
            results.append({'id':infos1_row[0],'vip':infos1_row[2]})
        my_db.close()
        return render(req,'index.html',locals())
    else:
        msg = "请求错误"
        return render(req,"msg.html", locals())

def add(req):
    if comfirm(req):
        my_db =  MynewcoderDB()
        #订单列表的插入
        sql1 = "insert into share ('old','new','start_time','end_time','dingdanhao','invitation','change_time')" \
              "values('old','new','start_time','end_time','dingdanhao','invitation','change_time')"
        #会员列表的插入
        sql2 = "insert into vip ('vipid','vip','create_time','change_time','deadline')" \
              "values('vipid','vip','create_time','change_time','deadline')"
        infos1 = my_db.execute(sql1)
        infos2 = my_db.execute(sql2)
        my_db.commit()
        my_db.close()
        return render(req,'index.html',locals())
    else:
        msg = "请求错误"
        return render(req,"msg.html", locals())

def change(req):
    if comfirm(req):
        try:
            text = req.POST['vip']
            my_db = MynewcoderDB()
            sql1 = "update share set old ='old',start_time='start_time',end_time='end_time',dingdanhao='dingdanhao',invitation='invitation',change_time='change_time'" \
                   "where new='text'"
            sql2 = "update vip set vipid='vipid',create_time='create_time',change_time='change_time',deadline='deadline'where vip= 'text'"
            infos1 = my_db.execute(sql1)
            infos2 = my_db.execute(sql2)
            my_db.commit()
            my_db.close()
            return render(req,'index.html',locals())
        except Exception as e:
            msg = '没有该信息，请重新查询'
            return render(req,"msg.html",locals())
    else:
        msg = "请求错误"
        return render(req,"msg.html", locals())


def vip_edit_action(req):
    if comfirm(req):
        res_id = req.POST.get('res_id','')
        res_vipid = req.POST.get('res_vipid','999999')
        res_mail = req.POST.get('res_mail','0')
        res_create_time = req.POST.get('res_create_time','2010-1-10')
        res_change_time = req.POST.get('res_change_time','2010-1-10')
        res_deadline = req.POST.get('deadline','2020-1-1')
        my_db = MynewcoderDB()
        if res_id == '0':
            try:
                sql3 = "select * from vip"
                infos3 = my_db.getInfo(sql3)
                results = []
                for infos1_row in infos3:
                    results.append({'id': infos1_row[0], 'vip': infos1_row[2]})
                return render(req, 'index.html', locals())
            except Exception as e:
                msg = '没有该信息，请重新查询'
                return render(req,"msg.html",locals())
        sql2 = "update vip set vipid="+res_vipid+" ,vip="+res_mail+", create_time="+res_create_time+",change_time="+res_change_time+",deadline="+res_deadline+" where id= "+res_id+""
        try:
            infos2 = my_db.execute(sql2)
            my_db.commit()
            sql4 = "select * from vip where id ="+res_id+" "
            infos4 = my_db.getInfo(sql4)
            results = []
            for infos1_row in infos4:
                results.append(
                    {'id': infos1_row[0], 'vipid': infos1_row[1], 'vip': infos1_row[2], 'create_time': infos1_row[3],
                     'change_time': infos1_row[4], 'deadline': infos1_row[5]})
            return render(req, 'member_edit.html', locals())
        except:
            my_db.rollback()
        my_db.close()
    else:
        msg = "请求错误"
        return render(req,"msg.html", locals())

def show(req,res_id):
    if comfirm(req):
        try:
            my_db = MynewcoderDB()
            sql = "select * from vip where id ="+res_id+" "
            infos = my_db.getInfo(sql)
            results = []
            for infos_row in infos:
                results.append({'id': infos_row[0], 'vipid': infos_row[1], 'vip': infos_row[2], 'create_time': infos_row[3],
                                'change_time': infos_row[4], 'deadline': infos_row[5]})
                my_db.close()
            return render(req,'member_edit.html',locals())
        except Exception as e:
            msg = '没有该信息，请重新查询'
            return render(req,"msg.html",locals())
    else:
        msg = "请求错误"
        return render(req,"msg.html", locals())

def search(req):
    if comfirm(req):
        try:
            text = req.POST['vip']
            my_db = MynewcoderDB()
            #vip
            sql1 = "select * from vip where vip LIKE '%"+text+"%'"
            infos1 = my_db.getInfo(sql1)
            results = []
            for infos1_row in infos1:
                results.append({'id':infos1_row[0],'vipid':infos1_row[1],'vip':infos1_row[2],'create_time':infos1_row[3],'change_time':infos1_row[4],'deadline':infos1_row[5]})
            my_db.close()
            return render(req,'member_edit.html',locals())
        except Exception as e:
            msg = '没有该信息，请重新查询'
            return render(req,"msg.html",locals())
    else:
        msg = "请求错误"
        return render(req,"msg.html", locals())

def vip_edit(req,res_id):
    if comfirm(req):#确认身份
        if res_id == '0':
            return render(req,'vip_edit.html')
        try:
            my_db = MynewcoderDB()
            sql1 = "select * from vip where id = "+res_id+" "
            infos1 = my_db.getInfo(sql1)
            results = []
            for infos1_row in infos1:
                results.append({'id':infos1_row[0],'vipid':infos1_row[1],'vip':infos1_row[2],'create_time':infos1_row[3],'change_time':infos1_row[4],'deadline':infos1_row[5]})
            my_db.close()
            res = results[0]
            return render(req,'vip_edit.html',locals())
        except Exception as e:
            msg = '没有该信息，请重新查询'
            return render(req,"msg.html",locals())
    else:
        msg = "请求错误"
        return render(req,"msg.html", locals())


def delete(req):
    if comfirm(req):
        try:
            if req.method == 'POST':
                text = req.POST.get("vip", '')
            else:
                text = req.GET.get("vip",'')
            my_db = MynewcoderDB()
            #vip表的删除
            sql1 = "delete from vip where vip like 'text'"
            #share即订单表的删除
            sql2 = "delete from share where new like 'text'"
            if name =='vip':
                infos = my_db.execute(sql1)
            if name =='dingdan':
                infos = my_db.execute(sql2)
            my_db.commit()
            my_db.close()
            return render(req,"index.html",locals())
        except Exception as e:
            msg = '没有找到相关信息'
            return render(req,"msg",locals())
    else:
        msg = "请求错误"
        return render(req,"msg.html", locals())

def invitation(req):
    pass
