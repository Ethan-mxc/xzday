from django.conf.urls import url
from vip import views
app_name = 'vip'
urlpatterns = [
    url(r'^index/$',views.index,name = 'index'),
    url(r'^search/$',views.search,name = 'search'),
    url(r'^change/$',views.change,name = 'change'),
    url(r'^delete/$', views.delete, name='delete'),
    url(r'^vip_edit/(?P<res_id>[0-9]+)$',views.vip_edit,name='vip_edit'),
    url(r'^show/(?P<res_id>[0-9]+)$', views.show, name='show'),
    url(r'^vip_edit/action$',views.vip_edit_action,name='vip_edit_action')
]
